
export default function HomePage() {
  return (
    <main className="min-h-[50vh] grid place-items-center">
      <h1 className="text-3xl font-bold text-blue-600">Tailwind فعاله ✔️</h1>
    </main>
  );
}
